# MobiSys 2027 review packet — EvCheck / cached-fact lifecycle evidence

**Paper:** Absent or Unchanged? What Android Tells a Cached-Fact Client After a Lifecycle Gap  
**Project folder:** P06-leasemem-mobile; current system name: EvCheck  
**Review date:** 2026-11-15 (Asia/Ho_Chi_Minh)  
**Target:** MobiSys 2027 regular research track  
**Recommendation:** Reject; preserve the measurement contribution and repair the correctness claims.  
**Panel scores:** 3 / 2 / 2 / 3 on a five-point scale.

## Review basis and interpretation

This is AI-generated author feedback: four simulated reviewer perspectives and a simulated meta-review, not four independent human reviews or an actual program-committee decision. Apply author judgment. Main sections, appendix proofs, selected generated tables/macros, bibliography context, compiled first page and PDF text were examined. The `observe`, `watermark`, `delta`, `missing` and `lmValidate` paths in `artifact/app/client/src/org/leasemem/client/LmApp.java` were inspected. Existing review headers and STATUS summaries were visible during discovery; this is not a blind replication of previous panels.

The current PDF has 17 pages. Its SHA-256 is `7df2c6d2136322696726d3fe66aae180f592f543942e10b3a52da809fc8f31b5`. The previous review is preserved in [review-before-2026-11-15.md](review/review-before-2026-11-15.md). The PDF was regenerated during this review with revised overview graphics; its final hash and page count were rechecked. This packet is a technical review, not a full visual-layout audit. No Android experiment, raw-trial reanalysis, LLM call or full rebuild was run. Two small Python state-transition checks confirmed the logical counterexample traces below; they are not device reproductions. Experimental rates elsewhere are manuscript-reported.

**Submission blocker:** `main.log` reports 9pt; page-2 PDF font extraction confirms it. The [official CFP](https://www.sigmobile.org/mobisys/2027/call_for_papers/) requires at least 10pt and limits main content to 12 pages, excluding references/appendices. Rebuild and recheck pagination. Technical scores assume compliant formatting.

**Scales:** Overall: 1 strong reject, 2 weak reject, 3 borderline, 4 weak accept, 5 strong accept. Dimensions: 1 poor through 5 excellent. Confidence: 1 low through 5 expert-level. These are local scales, not a claimed official review form. Overall scores are not dimension averages.

## Contribution and evidence map

| Claim | Evidence anchor | Assessment |
|---|---|---|
| Notifications are deferred, held or lost according to lifecycle and deployment | §3, E2/E9/E10 | Useful measured taxonomy on Android 13/15 emulators; timing and absence of loss are bounded observations. |
| Some provider sources expose useful durable change evidence | §3 E1 and E6 | Good source-by-source engineering map; timestamp adapters require stronger conditions than merely no backward clock movement. |
| Default assistants avoid observed background deferral/freezing | E10, `tab_deploy.tex` | Supports the measured bound-service configuration; does not make asynchronous callbacks instantaneous or every assistant configuration equivalent. |
| EvCheck avoids stale uses | §7 E2: 0/1,339 changed uses at the late decision | Supported on the staged workload. Does not establish the general theorem for concurrent observation/validation. |
| EvCheck improves device-side cost | §7 E8/E12, `tab_cost.tex` | Negative result: 44ms versus 32ms median provider decision time; input memoization wins for derived facts. |
| Host-side validation pays | E13, `tab_host.tex` | 8.0/8.1s versus 11.9s in unbatched adb measurements; a batched helper baseline is missing. |
| No-gap or FGS event-only behavior is sound | Abstract, §3/§8 | Empirical zero misses at selected observation times should not be generalized to arbitrary concurrent mutations. |
| Main motivation has broad agent coverage | E5 | Only 12 of 71 pre-existing-state task categories use exclusively evidence-equipped stores; classification is app/name based, not executed-task coverage. |

## Reviewer 1 — Android measurement and community value

**Overall: 3/5, borderline. Confidence: 4/5.**

| Dimension | Score | Reason |
|---|---:|---|
| Originality | 3 | Known mechanisms combined into a useful empirical source/deployment map. |
| Importance | 4 | Cached external state is a recurring mobile systems problem. |
| Claim support | 3 | Good measurement, but some universal soundness statements exceed it. |
| Experimental soundness | 3 | Broad controlled matrix, limited independent devices and natural workloads. |
| Writing clarity | 4 | Honest negative results substantially improve the paper. |
| Community value | 4 | Taxonomy and adapter tests could help developers choose simpler designs. |
| Prior-work contextualization | 4 | Clearly acknowledges classical cache validation and memoization. |

**Summary.** The paper asks what an Android client can infer when it has cached facts but missed or delayed notifications. It maps durable evidence by source, separates deferred callbacks from frozen and lost delivery, and evaluates different deployment modes and refresh strategies. The best contribution is the measurement and resulting design guidance, not EvCheck as a new cache algorithm.

**Strengths.** E9 tests long freezes rather than assuming short holds represent long ones. E10 checks the very deployment invoked by the motivation and finds that default assistants avoid the tested deferral/freezing conditions. The paper accepts the resulting negative lesson: restart-aware refresh is simpler in that setting. E8 also includes input memoization and reports that it beats evidence-based invalidation. Source-level pitfalls such as reused SMS identifiers, deleted maximum timestamps and transient clock changes give the paper practical substance. It distinguishes measured LLM-call sums from end-to-end agent latency.

**Major concerns.** The main claim now needs a clearer measurement thesis. Much of the notification behavior follows documented/source-defined Android mechanisms. The paper must say which combinations, unexpected boundaries or deployment consequences were not previously established. Android 15's additional delay is both a prominent result and unexplained; one emulator image cannot establish that behavior for Android 15 generally. Similarly, finding no lost callbacks in the tested frozen holds establishes source-level invalidation delivery in those trials, not an unlimited event-replay guarantee.

The “sound” label is too absolute in the abstract and guidance. A foreground callback still takes milliseconds; a critical use can occur before it. The staged +2s/+14s decisions deliberately avoid much of this window. The measurement remains useful after replacing universal soundness with “no misses under the tested schedule” and giving the concurrency contract explicitly.

**Questions for authors.** Which findings survive a physical-device replication? What is the source of Android 15's longer delay? Are frozen callbacks checked individually or only for at least one notification after the final source mutation? Can the contribution be stated without assuming an agent already uses event-driven provider memory?

**Recommendation and score movement.** Borderline. A focused lifecycle-evidence paper with corrected guarantees and a reusable conformance suite could earn weak accept. The current manuscript spends too much of its credibility on a validator whose broad correctness and cost advantages are not established.

## Reviewer 2 — Cache correctness and source-code correspondence

**Overall: 2/5, weak reject. Confidence: 4/5.**

| Dimension | Score | Reason |
|---|---:|---|
| Originality | 3 | Support checks and adapter catalog are useful, but not a new validation principle. |
| Importance | 4 | A false FRESH result can cause a wrong consequential action. |
| Claim support | 1 | Observation consistency and timestamp premises are not enforced. |
| Experimental soundness | 2 | Staged mutations omit important schedules allowed by the stated problem. |
| Writing clarity | 3 | Theory assumptions are explicit but stronger than operational guidance suggests. |
| Community value | 3 | Valuable if the adapter guarantees are repaired and narrowed. |
| Prior-work contextualization | 4 | Classical validation and incremental recomputation are properly acknowledged. |

**Summary.** The theorem is conditional on usable evidence, complete deltas and a well-defined observation. The implementation does not ensure that the cached value and its watermark describe the same source state. This is distinct from the already disclosed race between final validation and the eventual action.

**Strengths.** Returning UNKNOWN for evidence-less sources is appropriate. The support check addresses disappearing rows, MediaStore combines database version and generation, and the Contacts version-map adapter avoids the demonstrated wall-clock failure. The paper openly measures residual action-boundary races rather than claiming atomic execution.

**Major concern 1: inconsistent initial observation.** In `LmApp.java:430–445`, `observe()` reads all fact values, then all watermarks, then a separate Contacts version map. Consider a contact read as value A at generation/version 1. Another app changes it to B/version 2 before the watermark pass. The cache stores A with watermark 2. At a later quiet validation, the watermark is still 2 and the supporting row still exists, so `lmValidate()` takes its equality branch and returns FRESH for A. This violates the intended freshness statement before any action-boundary race occurs. A small state-transition check confirms the branch logic; no Android reproduction is claimed. The same issue must be checked when refreshed facts are re-anchored. Use a coherent provider snapshot or a validated before/after generation protocol where its assumptions hold, and make that premise explicit in the theorem.

**Major concern 2: timestamp resolution.** A1 requires every relevant new stamp to be strictly greater than the prior watermark. A clock that never goes backward is insufficient when multiple writes share a timestamp tick. The call-log adapter uses `MAX(last_modified)` (`watermark`, LASTMOD) with a clock-jump guard but no file-style racy-tick guard. An edit stamped with the same maximum leaves the watermark equal and all IDs present, yet changes a fact. The paper should prove this cannot occur for the tested provider or return UNKNOWN under the unsafe condition. E6's transient-clock example also remains relevant to call-log timestamps, even though Contacts has been repaired with versions.

**Major concern 3: validation is itself multiple reads.** Watermarks, support sets, deltas and keyed queries are not one snapshot. A theorem about a single validation instant needs a consistency argument for these reads, not only a later conditional commit. The paper acknowledges overlapping boundary changes empirically, but does not resolve what state its FRESH verdict certifies under concurrency.

**Questions for authors.** Where is atomic or double-checked anchoring implemented? What prevents equal-tick call-log edits? Which exact instant is certified when validation's queries straddle a mutation?

**Recommendation and score movement.** Weak reject. Correct the anchoring protocol, establish per-adapter assumptions and add targeted concurrent/timestamp tests before relying on the theorem. More quiet-gap trials cannot repair this correctness gap. The underlying measurement contribution remains salvageable.

## Reviewer 3 — Performance, alternatives and deployment relevance

**Overall: 2/5, weak reject. Confidence: 4/5.**

| Dimension | Score | Reason |
|---|---:|---|
| Originality | 2 | Validation mechanism is classical; value depends on the deployment evidence. |
| Importance | 3 | Relevant problem, but the target deployment often has a simpler solution. |
| Claim support | 2 | Sole positive speed setting lacks a strong batching comparator. |
| Experimental soundness | 3 | Strong negative baselines, incomplete host and policy realism. |
| Writing clarity | 4 | Performance losses are stated directly. |
| Community value | 3 | Useful guidance, weaker case for a full standalone mechanism. |
| Prior-work contextualization | 4 | Memoization and prior cache protocols are not hidden. |

**Summary.** EvCheck pays to validate source evidence and then refresh unsupported or affected facts. The experiments show that this loses to direct provider reads on device and to input memoization for derived facts. The remaining positive case is a host agent issuing separate adb/content-tool queries.

**Strengths.** The paper deserves credit for reporting 44ms median validation decision time against 32ms global refresh and for including the baseline that re-reads LLM inputs without re-deriving unchanged outputs. Scaling Contacts to thousands of rows also exposes the linear cost of digesting its entire version map. E10 challenges the deployment premise instead of assuming the most restrictive background configuration applies to a privileged assistant.

**Major concerns.** E13's 11.9s versus 8.0–8.1s difference is dominated by process/tool launches and round trips, as the authors acknowledge. A host can invoke one on-device helper to read all required facts or watermarks, and a notification helper can relay changes even if the host itself cannot register a ContentObserver. The correct comparison is unbatched/batched refresh versus unbatched/batched evidence validation under equal privileges. Without it, the claimed uniquely beneficial setting may be a transport artifact.

The agent relevance is also limited by provenance and coverage. The system assumes each fact has a source query and support set. Many GUI-visible facts lack these bindings; E5 classifies 53 of 71 pre-existing-state task categories as GUI/app-private and only 12 as exclusively evidence-backed. Counting task names and app stores is a useful screen, not evidence that a working agent can extract that provenance or avoid stale decisions.

The foreground-service cost claim should remain narrow. E11 uses BatteryStats' model on emulators in short windows, not physical energy measurement. The app targets API 33, so the newer service-type/time-limit discussion is not a tested deployment. Neither the notification-policy tradeoff nor “nearly free” energy is established across supported modern app configurations.

**Questions for authors.** Does validation beat a batched content helper? What setup and privilege differences exist between the alternatives? How much time is saved in an actual agent task after provenance, UNKNOWN refreshes and final revalidation are included?

**Recommendation and score movement.** Weak reject as an efficiency or agent-memory system. A measurement paper could overcome this by emphasizing when simpler designs win and validating a genuinely useful residual case. I would not request a larger model; fair transport baselines and concrete deployment evidence matter more.

## Reviewer 4 — Experimental design, statistics and presentation

**Overall: 3/5, borderline. Confidence: 4/5.**

| Dimension | Score | Reason |
|---|---:|---|
| Originality | 3 | Good empirical organization of a fragmented platform interface. |
| Importance | 4 | Lifecycle-dependent evidence is relevant beyond LLM agents. |
| Claim support | 3 | Conditional results are credible; broad soundness claims need correction. |
| Experimental soundness | 3 | Paired policy evaluation and trial-level reporting help, with residual confounds. |
| Writing clarity | 3 | Main narrative is overloaded and repeatedly shifts audience. |
| Community value | 4 | Source/deployment matrix and regression tests would be useful artifacts. |
| Prior-work contextualization | 4 | Broad and mostly fair. |

**Summary.** The paper presents an extensive controlled campaign, including source probes, lifecycle gaps, deployment variants, clock tests and cost comparisons. It is strongest when describing what happened under each precisely stated configuration, and weakest when turning those observations into unconditional advice.

**Strengths.** The authors recognize that derived facts are dependent and provide trial-level outcomes rather than treating every fact use as independent replication. Policies share decisions and ground truth. Exclusions disclose incorrect freezer state, leaked FGS configuration, host sleep and Doze maintenance windows. Long-Doze repeats and actual cgroup checks are better than assuming a command succeeded. The boundary experiment separates mutations before checking, during checking and after effect.

**Concerns.** Important per-gap and trial-level evidence is relegated to the appendix. The main text should contain at least one compact table with independent trial counts, stale-trial rates and uncertainty by deployment; the number of changed fact uses alone can look more conclusive than it is. Zero missed source invalidations in long frozen holds should not be described as lossless delivery of every callback unless each callback is tracked. A few surviving frozen trials do not bound all buffer pressure or kill conditions.

The data-generation protocol mutates after observation and waits before decisions. That is appropriate for studying gaps, but it systematically avoids the initial anchoring race and very short notification-latency races. A companion interleaving campaign is needed if the paper keeps the formal freshness claim. Waiting a fixed 10s or 30s does not establish freshness during continuous background writes; it only drains sufficiently old notifications under additional quiescence assumptions.

The default-assistant result is measured for an active bound VoiceInteractionService. It should be tied to that process state, not generalized to every default assistant or helper process. A source mutation and callback can always be ordered around a critical read unless the protocol establishes a barrier.

**Questions for authors.** What is the independent trial count behind each zero-miss headline? Can the body distinguish quiescent reconciliation from continuously mutating critical use? Which policy decisions remain correct when mutations are injected during observation rather than only afterward?

**Recommendation and score movement.** Borderline. I support the direction as a measurement contribution, but would need a corrected claim taxonomy, targeted interleaving tests and more concise main-text evidence to advocate acceptance. More bibliography or additional quiet repetitions would not move the score much.

## Correctness findings: exact scope and proposed validation

These are source-level findings and logical traces, not newly observed Android failures.

| Finding | Inspected evidence | Trace or obligation | Required validation |
|---|---|---|---|
| Observation anchor can certify an old value with a new version | `LmApp.java:430–445`; §4 memory entry construction | Read A/v1, mutate to B/v2, record v2, later compare v2 and return FRESH for A. | Inject mutation between fact read and watermark read; make anchoring coherent and test re-anchoring too. |
| Same-tick timestamp change can be invisible | `watermark` LASTMOD at approximately line 332; `lmValidate` equality branch at approximately line 489 | Same maximum timestamp, same IDs, different row value. Nondecreasing time does not imply A1's strict increase. | Same-tick call-log edits and transient clock restoration, with verified stamp values. |
| Multi-query validation lacks a stated snapshot guarantee | §4 Algorithm 1; sequential watermark/support/delta reads | An overlapping mutation can produce an inconsistent evidence set; no single validation instant is established merely by sequencing calls. | Snapshot or before/after validation protocol with explicit assumptions and rejection/retry behavior. |
| Fast notification is not zero-latency certification | E10 plus §8 advice | Mutation commits, decision uses cache, callback arrives milliseconds later. | Test uses near callback delivery; scope zero-miss findings to measured schedules. |
| Fixed waits need quiescence | §8 wait-out-deferral guidance | A new mutation just before decision is not made safe by waiting for an older one. | State a writer-quiescence/barrier premise or perform a source read. |

The two Python model checks for the first two rows both reached `fresh=True, stale=True`. They verify the proposed counterexample logic only. A device test is still needed to quantify whether and how often each schedule occurs for a particular provider.

## Related-work, baseline and theory audit

Nine targeted primary sources were checked. Most are already cited; the gap is in the operational mapping and baselines.

| Source | What it should change in this paper |
|---|---|
| [HTTP Semantics, RFC 9110](https://www.rfc-editor.org/info/rfc9110/) | Distinguish strong validators from weaker timestamp evidence; identify what a cached value/version pair certifies. |
| [WebDAV collection synchronization, RFC 6578](https://www.rfc-editor.org/rfc/rfc6578) | Specify token invalidation/reset behavior and complete delta semantics. |
| [MediaStore API](https://developer.android.com/reference/android/provider/MediaStore) | Keep database version and generation together and establish a consistent observation boundary. |
| [RawContacts API](https://developer.android.com/reference/android/provider/ContactsContract.RawContacts) | Explain version scope, row identity and the cost of reading the full map. |
| [ContentObserver API](https://developer.android.com/reference/android/database/ContentObserver) | Separate change notification from a durable history or a synchronous commit barrier. |
| [Android 14 behavior changes](https://developer.android.com/about/versions/14/behavior-changes-all) | Keep process-state and cached-execution conclusions tied to platform behavior and actual runtime state. |
| [Foreground-service timeouts](https://developer.android.com/develop/background-work/services/fgs/timeout) | Distinguish documented restrictions from tests of an API-33-targeting client; avoid implying current-target deployment was exercised. |
| [Build Systems à la Carte](https://www.microsoft.com/en-us/research/publication/build-systems-la-carte/) | Treat input memoization as a serious alternative and distinguish stamp-based from content-based reuse. |
| [AndroidWorld](https://arxiv.org/abs/2405.14573) | Pin task definitions and validate app/name-derived coverage with actual query/provenance inspection. |

Highest-value missing baselines are batched on-device reads exposed to a host, a host with a notification relay, refresh-before-critical-use, and consistent observation plus memoization. The useful theory improvement is an explicit consistency contract for observation, validation and effect, rather than further generic cache-invalidity results. The “minimal sound design” claim also needs a definition of minimality or softer wording.

## Writing and argument audit

| Location | Issue | Fix |
|---|---|---|
| Abstract and §1 | The long abstract combines taxonomy, deployment, proof and negative performance results. | Lead with the measured Android evidence map and its consequences; shorten mechanism claims. |
| §3/E10 and §8 | “Restart-aware refresh is sound” conflates epoch-break recovery with concurrent in-epoch freshness. | State quiescence and callback-delivery assumptions; preserve the empirical result. |
| §4–§5 | A watermark obtained after a fact is treated as if obtained atomically with it. | Add a consistent anchoring protocol and use its actual state in the theorem. |
| §5 | “Clock never moves backwards” is weaker than strictly increasing stamps. | Separate resolution, monotonicity, rollback and reset assumptions per adapter. |
| §7/E13 | “Cheaper than every alternative” exceeds the evaluated unbatched configurations. | Say “cheaper than the measured unbatched baselines,” then add batching. |
| §8 | “Minimal sound design” and waiting advice sound universal. | Define the design space or replace with conditional guidance. |

The writing is candid and technically specific. The main issue is overgeneralization from carefully staged measurements, not lack of limitations or generic prose. No writing-provenance inference is warranted from style.

## Meta-review

**Decision: Reject; substantial revision encouraged as a measurement paper.**

R1 and R4 see a valuable source/deployment taxonomy and appreciate the honest negative results. R3 does not see a demonstrated performance advantage against the strongest practical host baseline. R2 identifies a correctness gap in how observations are anchored, plus unestablished timestamp and multi-query consistency premises. The committee-level judgment is that these issues are central to the current “sound design” claim and cannot be treated as cosmetic shepherding.

The reported zero-miss counts are not dismissed: they support the tested gap protocol. They do not cover mutations during initial observation, during validation or immediately before asynchronous callback delivery. Similarly, the default-assistant and memoization results are valuable lessons, but narrow the case for a new validator. A stronger revision would foreground the Android evidence map, repair or explicitly narrow the validator, and make deployment recommendations conditional on actual process state, source semantics and transport cost.

The most important work is to fix the observation/version contract, test the missing schedules, and compare batched host strategies. Physical-device verification and a concise trial-level evidence table would then strengthen the measurement contribution. The current formatting must also be repaired before submission.

**Acceptance calibration:** about **10–25% after formatting correction at current technical scope**, confidence 3/5. Corrected guarantees, targeted interleaving tests, fair host baselines and a focused measurement narrative could plausibly raise the band to **35–55%**. These are subjective author-feedback estimates rather than objective probabilities. The exact current PDF is not submission-ready.

## Revision checklist

### Submission prerequisite

- [ ] **P0 — Rebuild at 10pt and recheck the main-body limit.** The current body already extends to page 12, so plan cuts before reflow; preserve core trial-level evidence.

### Decision-critical correctness work

- [ ] **P1 — Make observation and re-anchoring consistent.** Add a provider snapshot or validated before/after evidence protocol; record precisely which value each stored version certifies.
- [ ] **P1 — Reproduce the observation race on a device.** Inject a mutation between a fact read and watermark read and verify that the repaired client never labels an old value FRESH.
- [ ] **P1 — Establish per-adapter stamp assumptions.** Test equal-tick call-log edits, rollback/restore, resets, deletions and identity reuse. Return UNKNOWN where strict evidence cannot be guaranteed.
- [ ] **P1 — Define validation's certified instant.** Address overlapping watermark, support, delta and query reads separately from the later action-boundary race.
- [ ] **P1 — Narrow event-only soundness and wait guidance.** Distinguish zero misses under tested timing from a guarantee under concurrent writes; state any quiescence/barrier assumption.

### Decision-critical evaluation and framing

- [ ] **P1 — Add fair host transport baselines.** Batched refresh and batched validation using the same on-device helper and privileges; include a notification relay if relevant.
- [ ] **P1 — Recenter the contribution on the measurement.** Preserve the findings that direct refresh and memoization win in important deployments; justify the remaining use case without universal efficiency claims.
- [ ] **P1 — Put independent trial-level evidence in the body.** Report stale-trial counts and uncertainty for deployment/gap groups, including zero-result denominators.

### Strongly recommended

- [ ] **P2 — Replicate on current physical devices.** Diagnose Android 15's extra deferral and tie assistant results to a bound service/process state.
- [ ] **P2 — Test continuously mutating use.** Include observation, reconciliation, callback-delivery and action intervals, not only mutation-after-observation gaps.
- [ ] **P2 — Validate task/provenance coverage.** Inspect representative actual queries and validators rather than only task names/app stores; report UNKNOWN behavior explicitly.
- [ ] **P2 — Calibrate FGS resource conclusions.** Keep emulator BatteryStats estimates separate from physical energy; test current target-SDK restrictions before claiming deployability.
- [ ] **P2 — Verify the artifact and exclusions.** Retain invalid runs, configuration checks and deterministic generation, and test a clean anonymous retrieval/rebuild.

### Presentation and optional work

- [ ] **P3 — Shorten the abstract and remove universal minimality claims.** Use a source/deployment/appropriate-strategy table.
- [ ] **P3 — Package an adapter conformance suite.** Include reset, concurrent-read, same-tick, deletion and unsupported-source cases with expected verdicts.
